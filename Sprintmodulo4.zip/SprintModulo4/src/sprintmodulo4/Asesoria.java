package sprintmodulo4;

public interface Asesoria {
    public String analizarUsuario();
}
